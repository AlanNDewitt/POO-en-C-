//Hola profa, antes de que revise mi codigo quisiera decirle que tiene un peque�o bug de optimizacion,por haberlo manejado con clases, 
//el programa le pedira que compile con -std=c++11 este se activa en herramientas/opcionesdecompilador/configuracion/generadordecodigo/ y seleciona c++17
//me gustaria que revise mi codigo ya que esta hecho con clases pero como no corre por el bug que le comente, mi programa esta escrito sin clases
// para que viera que si corre.
// En cada linea de codigo explico que hace cada funcion.  

//Profa este programa lo hice yo, Rey Martin, si usted no permite esto, solo bajeme calificacion a mi ya que mis compa�eros trabajaron bien.

#include <iostream>
#include <windows.h>
#include <conio.h>
#include <stdio.h>
#include <libgame.h>

// codigo ASCII
#define IZQUIERDA 75
#define DERECHA 77

using namespace std;

// libreria windows.h
/*
void gotoxy(int x, int y)
{
    HANDLE hcon;
    COORD dwPos;

    dwPos.X = x;
    dwPos.Y = y;

    hcon = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleCursorPosition(hcon, dwPos);
}
*/

class Avion{

	private:

	
int ix; //coordenada X del avion
int iy; // coordenada Y del avion

	
	public:
char borrar_avion[7]= {' ',' ',' ',' ',' ',' ',' '};	// esta linea sirve para borrar el avion, primero se borra y luego se imprime el avion en la posicion deseada
		
		
char avion_l1[7]= {' ',' ',' ', '*',' ',' ',' '};
char avion_l2[7]= {' ',' ','*', '*','*',' ',' '}; //AVION
char avion_l3[7]= {' ','*',' ', '*',' ','*',' '};

char explocion_l1[7]= {' ',' ','*','*',' ',' ',' '};
char explocion_l2[7]= {' ','*','*','*','*',' ',' '}; //Avion Explotando1
char explocion_l3[7]= {' ',' ','*','*',' ',' ',' '};

char explocion_r1[7]= {'*',' ','*','*',' ','*',' '};
char explocion_r2[7]= {' ','*','*','*','*',' ',' '}; // Avion explotanto2
char explocion_r3[7]= {'*',' ','*','*',' ','*',' '};
	
	void set_x_y()
	{
		ix = 40; 
		iy = 19; 
	}
	
	void movi_izq()
	{
		ix = ix - 2;
	}
	
	void movi_derecha()
	{
		ix = ix + 2;
	}
	
	void subir_y()
	{
		iy = iy - 2;
	}

	int get_ix()
	{
		return ix;
	}
	
	int get_iy()
	{
		return iy;
	}
	
	void avion_explota()
	{
    	gotoxy(ix,iy);
    	puts(explocion_l1);
    	gotoxy(ix,iy+1);
    	puts(explocion_l2); // + 1 en eje Y para que se imprima en la linea de abajo
    	gotoxy(ix,iy+2);
    	puts(explocion_l3); // + 1 en eje Y para que se imprima en la linea de abajo

    	Sleep(380); // para que se vea la explosion, sino el programa va muy rapido y no se ve

    	gotoxy(ix,iy);
    	puts(explocion_r1);
    	gotoxy(ix,iy+1);
    	puts(explocion_r2);
    	gotoxy(ix,iy+2);
    	puts(explocion_r3);

    	Sleep(380);

    	gotoxy(ix,iy);
    	puts(avion_l1);
    	gotoxy(ix,iy+1);
    	puts(avion_l2);
    	gotoxy(ix,iy+2);
    	puts(avion_l3);

	}
	
};

class Asteroides{
	private:
// coordenada primer asteroide
	int y = 8, x = 12;

// asteroide 2
	int yy = 12, xx = 17;

// asteroide 3
	int x1 = 58, y1 = 6;

// asteroide 4
	int x2 = 70, y2 = 9;
	
	
	public:
	int get_y()
	{
		return y;
	}
	
	int get_x()
	{
		return x;
	}
	
	int get_yy()
	{
		return yy;
	}
	
	int get_xx()
	{
		return xx;
	}
	
	int get_x1()
	{
		return x1;
	}
	
	int get_y1()
	{
		return y1;
	}
	
	int get_x2()
	{
		return x2;
	}
	
	int get_y2()
	{
		return y2;
	}

};

class Vida{
	private:
	int num_vidas = 3;
	int corazones = 3;
	
	public:
	
// imrpime la cantidad de corazones que le diga
int get_numvidas()
{
	return num_vidas;
}

int get_corazones()
{
	return corazones;
}

void baja_corazones()
{
	corazones =-1;
}

void baja_vida()
{
	num_vidas=-1;
}

void reinicia_vida()
{
	corazones = 3;
}

void barra_salud()
{
    gotoxy(72,1);
    cout << " ";
    gotoxy(73,1);
    cout << " ";
    gotoxy(74,1);
    cout << " ";

    for(int v = 0; v < corazones; v++)
    {
        gotoxy(72+v,1);
        printf("%c", 3); // en el codigo ASCII es un corazon
    }

}

void vidas()
{
    gotoxy(2, 1);
    cout << "VIDAS: " << num_vidas;
}

};


class Play: public Avion, public Asteroides, public Vida 
{

public:
	
int repeticion = 0;
int nivel = 1;
bool condicion = false;

friend void juego(Play SpaceI);	

		
};

void juego(Play SpaceI)
{
int dd = 0, r;
int xb;
bool disparo = false;

char avion_l1[]= {' ',' ',' ', '*',' ',' ',' ',0};
char avion_l2[]= {' ',' ','*', '*','*',' ',' ',0};
char avion_l3[]= {' ','*',' ', '*',' ','*',' ',0};

char explocion_l1[7]= {' ',' ','*','*',' ',' ',' '};
char explocion_l2[7]= {' ','*','*','*','*',' ',' '}; //Avion Explotando1
char explocion_l3[7]= {' ',' ','*','*',' ',' ',' '};

char explocion_r1[]= {'*',' ','*','*',' ','*',' ',0};
char explocion_r2[]= {' ','*','*','*','*',' ',' ',0};
char explocion_r3[]= {'*',' ','*','*',' ','*',' ',0};

char borrar_avion[7]= {' ',' ',' ',' ',' ',' ',' '};	// esta linea sirve para borrar el avion, primero se borra y luego se imprime el avion en la posicion deseada

    // xb guarda la posicion del avion al momento del disparo para que la bala no siga al avi�n cuando se dispara
    if(disparo == false)
    {
        xb = SpaceI.get_ix();
    }
    
    gotoxy(xb+3, SpaceI.get_iy()+dd); printf("*");  // COORDENADA X ser�a igual a avion_l1[3] (osea, el asterisco del avion || la punta)

	int y = 8, x = 12;


	int yy = 12, xx = 17;


	int x1 = 58, y1 = 6;


	int x2 = 70, y2 = 9;

	// rutina de los asteroides
    gotoxy(x , y);
    printf("%c", 2); // 2: codigo ASCII de asteroide
    gotoxy(xx, yy);
    printf("%c", 2);
    gotoxy(x1, y1);
    printf("%c", 2);
    gotoxy(x2, y2);
    printf("%c", 2);

    Sleep(70);

    // borra los asteroides despues de imprimirlos
    gotoxy(x, y); printf(" ");
    gotoxy(xx, yy); printf(" ");
    gotoxy(x1, y1); printf(" ");
    gotoxy(x2, y2); printf(" ");

    gotoxy(xb+3, SpaceI.get_iy()+dd); printf(" ");


    // cada vez que disparo, dd decrementa en uno (osea, la bala va para arriba de la pantalla)
    if(disparo == true)
    {
        dd--;
    }

    if(SpaceI.get_iy() + dd < 5) // 5 es la coordenada de Y de donde salen los asteroides
    {
        dd = 0;
        disparo = false;  // se deja de ejecutar el IF de disparo
    }

    // cuando el asteroide llega hasta abajo del todo, vuelve para arriba
    // la posicion X siempre va a ser random !!
    // x == xb + 3 && iy + dd <= y .... cuando la bala le pega al asteroide, tambien vuelve para arriba
    if(y > 20 || x == xb + 3 && SpaceI.get_iy() + dd <= y)
    {
        y = 4;
        x = (rand()%70) + 6;

        // cuando el asteroide toca el piso y vuelve para arriba
        if(y == 4)
        {
        	SpaceI.condicion = false;
        }
    }

    if(yy > 20 || xx == xb + 3 && SpaceI.get_iy() + dd <= yy)
    {
        yy = 4;
        xx = (rand()%70) + 6;
    }

    if(y1 > 20 || x1 == xb + 3 && SpaceI.get_iy() + dd <= y1)
    {
        y1 = 4;
        x1 = (rand()%70) + 6;
    }

    if(y2 > 20 || x2 == xb + 3 && SpaceI.get_iy() + dd <= y2)
    {
        y2 = 4;
        x2 = (rand()%70) + 6;
    }

    // rutina para mover el avion
    if(kbhit()) // si se presiona una tecla
    {
        char tecla = getch();

        switch(tecla)
        {
        case IZQUIERDA:
            // para que no se salga de la pantalla
            if(SpaceI.get_ix() > 4)
            {
                // primero se borra el avion
                gotoxy(SpaceI.get_ix(), SpaceI.get_iy()   ); puts(borrar_avion);
                gotoxy(SpaceI.get_ix(), SpaceI.get_iy() +1); puts(borrar_avion);
                gotoxy(SpaceI.get_ix(), SpaceI.get_iy() +2); puts(borrar_avion);

                // le da movimiento al avion hacia la izquierda
               
                cout<<SpaceI.get_ix()<<","<<SpaceI.get_iy()<<endl;
				SpaceI.movi_izq();

                // ahora dibujamos el avion en las nuevas coordenadas
                cout<<SpaceI.get_ix()<<","<<SpaceI.get_iy();
                
                gotoxy(SpaceI.get_ix(), SpaceI.get_iy()   ); puts(avion_l1);
                gotoxy(SpaceI.get_ix(), SpaceI.get_iy() +1); puts(avion_l2);
                gotoxy(SpaceI.get_ix(), SpaceI.get_iy() +2); puts(avion_l3);
            }
            break;

        case DERECHA:
            // para que no se salga de la pantalla
            if(SpaceI.get_ix() < 70)
            {
                gotoxy(SpaceI.get_ix(), SpaceI.get_iy()   ); puts(borrar_avion);
                gotoxy(SpaceI.get_ix(), SpaceI.get_iy() +1); puts(borrar_avion);
                gotoxy(SpaceI.get_ix(), SpaceI.get_iy() +2); puts(borrar_avion);

                // le da movimiento al avion hacia la derecha
                SpaceI.movi_derecha();

                // ahora dibujamos el avion en las nuevas coordenadas
                gotoxy(SpaceI.get_ix(), SpaceI.get_iy()   ); puts(avion_l1);
                gotoxy(SpaceI.get_ix(), SpaceI.get_iy() +1); puts(avion_l2);
                gotoxy(SpaceI.get_ix(), SpaceI.get_iy() +2); puts(avion_l3);
            }
            break;

        case 'd':
            disparo = true;
            break;
        } // fin del SWITCH
    } // fin del IF

    // rutina para golpes de asteroides
    // coordenadas que abarca el avion en X
    if((x > SpaceI.get_ix() && x < SpaceI.get_ix() +6 && y == SpaceI.get_iy()-1) || (xx > SpaceI.get_ix() && xx < SpaceI.get_ix() +6 && yy == SpaceI.get_iy()-1) || (x1 > SpaceI.get_ix() && x1 < SpaceI.get_ix() +6 && y1 == SpaceI.get_iy()-1) ||(x2 > SpaceI.get_ix() && x2 < SpaceI.get_ix() +6 && y2 == SpaceI.get_iy()-1))
    {
    SpaceI.baja_corazones();
    
    SpaceI.barra_salud();
    
    printf("\a"); // hace el ruidito cuando le pega

    }
    // imprime el avion
    gotoxy(SpaceI.get_ix(), SpaceI.get_iy()   ); puts(avion_l1);
    gotoxy(SpaceI.get_ix(), SpaceI.get_iy() +1); puts(avion_l2);
    gotoxy(SpaceI.get_ix(), SpaceI.get_iy() +2); puts(avion_l3);

    if(SpaceI.get_corazones() == 0)
    {
        SpaceI.baja_vida();
        SpaceI.vidas();
        SpaceI.avion_explota();
        SpaceI.reinicia_vida();
        SpaceI.barra_salud();
    }

    // rutina para cambio de nivel
    if(SpaceI.condicion == false)
    {
        SpaceI.repeticion++;
        SpaceI.condicion = true;
    }
    // cuando el asteroide haya subido 15 veces, sube el nivel
    if(SpaceI.repeticion == 15)
    {
    	
        SpaceI.nivel ++;
        gotoxy(35, 1); cout << "NIVEL: " << SpaceI.nivel;

        //borra el avion de donde estaba y lo imprime mas arriba
        gotoxy(SpaceI.get_ix(), SpaceI.get_iy()  ); puts(borrar_avion);
        gotoxy(SpaceI.get_ix(), SpaceI.get_iy()+1); puts(borrar_avion);
        gotoxy(SpaceI.get_ix(), SpaceI.get_iy()+2); puts(borrar_avion);

        SpaceI.subir_y();

        gotoxy(SpaceI.get_ix(), SpaceI.get_iy()   ); puts(avion_l1);
        gotoxy(SpaceI.get_ix(), SpaceI.get_iy() +1); puts(avion_l2);
        gotoxy(SpaceI.get_ix(), SpaceI.get_iy() +2); puts(avion_l3);

        // para que se repita el bucle del cambio de nivel
        SpaceI.repeticion = 0;
    }

    // incremento de los asteroides
    y++;
    yy++;
    y1++;
    y2++;

}


/*
int main()
{

	char avion_l1[]= {' ',' ',' ', '*',' ',' ',' ',0};
	char avion_l2[]= {' ',' ','*', '*','*',' ',' ',0}; // 
	char avion_l3[]= {' ','*',' ', '*',' ','*',' ',0};

	Play SpaceI;
	
	SpaceI.set_x_y();	
	SpaceI.vidas();// numero inicial de vidas = 3
    SpaceI.barra_salud(); // numero inicial de corazones = 3
	gotoxy(35, 1); cout << "NIVEL: " << SpaceI.nivel;


     // Aqui esta el bug que le digo como puede ver, estas lineas 491-493 hacen lo mismo que las lineas 496-498 solo que en la funcion de puts manda como parametro una funcion y esto hace que se buge pero puse estas variables en main y ya no se bugea, pero pasa lo mismo con las demas lineas de codigo.

    // imprime el avion en su posicion inicial
//    gotoxy(SpaceI.get_ix(), SpaceI.get_iy()   );puts(SpaceI.avion_l1);
//    gotoxy(SpaceI.get_ix(), SpaceI.get_iy() +1);puts(SpaceI.avion_l2);
//    gotoxy(SpaceI.get_ix(), SpaceI.get_iy() +2);puts(SpaceI.avion_l3);
 

 	gotoxy(SpaceI.get_ix(), SpaceI.get_iy()   ); puts(avion_l1);
    gotoxy(SpaceI.get_ix(), SpaceI.get_iy() +1); puts(avion_l2);
    gotoxy(SpaceI.get_ix(), SpaceI.get_iy() +2); puts(avion_l3);
 
 	
 	
 	
    while(SpaceI.get_numvidas() > 0 && SpaceI.nivel <= 6)
	{	
 //   	juego(SpaceI);
    }

 //   gotoxy(20, 15); cout << "GAME OVER";
    // si al final apretamos una tecla, sale del programa
 //   getch();

 //   return 0;

}*/

// AQUI EMPIEZA EL PROGRAMA QUE SE EJECUTA, MI PRIMERA VERSION DEL JUEGO PORQUE LA QUE HICE CON CLASES NO CORRE POR OPTIMIZACION

void gotoxy(int x, int y);
void vidas(int vi);
void barra_salud(int n);
void avion_explota();
void Space_invaders();
void jugar();

char avion_l1[]= {' ',' ',' ', '*',' ',' ',' ',0};
char avion_l2[]= {' ',' ','*', '*','*',' ',' ',0};
char avion_l3[]= {' ','*',' ', '*',' ','*',' ',0};

char explocion_l1[]= {' ',' ','*','*',' ',' ',' ',0};
char explocion_l2[]= {' ','*','*','*','*',' ',' ',0};
char explocion_l3[]= {' ',' ','*','*',' ',' ',' ',0};

char explocion_r1[]= {'*',' ','*','*',' ','*',' ',0};
char explocion_r2[]= {' ','*','*','*','*',' ',' ',0};
char explocion_r3[]= {'*',' ','*','*',' ','*',' ',0};

// esta linea sirve para borrar el avion, primero se borra y luego se imprime el avion en la posicion deseada
char borrar_avion[]= {' ',' ',' ',' ',' ',' ',' ',0};

int num_vidas = 3;
int corazones = 3;
int ix = 40; //coordenada X del avion
int iy = 19; // coordenada Y del avion

// coordenada primer asteroide
int y = 8, x = 12;

// asteroide 2
int yy = 12, xx = 17;

// asteroide 3
int x1 = 58, y1 = 6;

// asteroide 4
int x2 = 70, y2 = 9;

// variables para disparar
int dd = 0;
int xb;
bool disparo = false;

// variables para determinar el nivel
int repeticion = 0;
int nivel = 1;
bool condicion = false;

using namespace std;

/*
int main()
{
 
 Space_invaders();
 
}

*/

void Space_invaders()
{
	system("cls");
	
	vidas(num_vidas); // numero inicial de vidas = 3
    barra_salud(corazones); // numero inicial de corazones = 3
    gotoxy(35, 1); cout << "NIVEL: " << nivel;


    // imprime el avion en su posicion inicial
    gotoxy(ix, iy); puts(avion_l1);
    gotoxy(ix, iy +1); puts(avion_l2);
    gotoxy(ix, iy +2); puts(avion_l3);

    while(num_vidas > 0 && nivel <= 6){
    jugar();
    }

    gotoxy(20, 15); cout << "GAME OVER";
    // si al final apretamos una tecla, sale del programa
    getch();

}


void vidas(int vi)
{
    gotoxy(2, 1);
    cout << "VIDAS: " << vi;
}

// imrpime la cantidad de corazones que le diga
void barra_salud(int n)
{
    gotoxy(72,1);
    cout << " ";
    gotoxy(73,1);
    cout << " ";
    gotoxy(74,1);
    cout << " ";

    for(int v = 0; v < n; v++)
    {
        gotoxy(72+v,1);
        printf("%c", 3); // en el codigo ASCII es un corazon
    }

}

void avion_explota()
{
    gotoxy(ix,iy);
    puts(explocion_l1);
    gotoxy(ix,iy+1);
    puts(explocion_l2); // + 1 en eje Y para que se imprima en la linea de abajo
    gotoxy(ix,iy+2);
    puts(explocion_l3); // + 1 en eje Y para que se imprima en la linea de abajo

    Sleep(380); // para que se vea la explosion, sino el programa va muy rapido y no se ve

    gotoxy(ix,iy);
    puts(explocion_r1);
    gotoxy(ix,iy+1);
    puts(explocion_r2);
    gotoxy(ix,iy+2);
    puts(explocion_r3);

    Sleep(380);

    gotoxy(ix,iy);
    puts(avion_l1);
    gotoxy(ix,iy+1);
    puts(avion_l2);
    gotoxy(ix,iy+2);
    puts(avion_l3);

}

void jugar()
{
    // xb guarda la posicion del avion al momento del disparo para que la bala no siga al avi�n cuando se dispara
    if(disparo == false)
    {
        xb = ix;
    }

   gotoxy(xb+3, iy+dd); printf("*");  // COORDENADA X ser�a igual a avion_l1[3] (osea, el asterisco del avion || la punta)

// rutina de los asteroides
    gotoxy(x, y);
    printf("%c", 2); // 2: codigo ASCII de asteroide
    gotoxy(xx, yy);
    printf("%c", 2);
    gotoxy(x1, y1);
    printf("%c", 2);
    gotoxy(x2, y2);
    printf("%c", 2);

    Sleep(70);

    // borra los asteroides despues de imprimirlos
    gotoxy(x, y); printf(" ");
    gotoxy(xx, yy); printf(" ");
    gotoxy(x1, y1); printf(" ");
    gotoxy(x2, y2); printf(" ");

    gotoxy(xb+3, iy+dd); printf(" ");


    // cada vez que disparo, dd decrementa en uno (osea, la bala va para arriba de la pantalla)
    if(disparo == true)
    {
        dd--;
    }

    if(iy + dd < 5) // 5 es la coordenada de Y de donde salen los asteroides
    {
        dd = 0;
        disparo = false;  // se deja de ejecutar el IF de disparo
    }

    // cuando el asteroide llega hasta abajo del todo, vuelve para arriba
    // la posicion X siempre va a ser random !!
    // x == xb + 3 && iy + dd <= y .... cuando la bala le pega al asteroide, tambien vuelve para arriba
    if(y > 20 || x == xb + 3 && iy + dd <= y)
    {
        y = 4;
        x = (rand()%70) + 6;

        // cuando el asteroide toca el piso y vuelve para arriba
        if(y == 4)
        {
            condicion = false;
        }
    }

    if(yy > 20 || xx == xb + 3 && iy + dd <= yy)
    {
        yy = 4;
        xx = (rand()%70) + 6;
    }

    if(y1 > 20 || x1 == xb + 3 && iy + dd <= y1)
    {
        y1 = 4;
        x1 = (rand()%70) + 6;
    }

    if(y2 > 20 || x2 == xb + 3 && iy + dd <= y2)
    {
        y2 = 4;
        x2 = (rand()%70) + 6;
    }

    // rutina para mover el avion
    if(kbhit()) // si se presiona una tecla
    {
        char tecla = getch();

        switch(tecla)
        {
        case IZQUIERDA:
            // para que no se salga de la pantalla
            if(ix > 4)
            {
                // primero se borra el avion
                gotoxy(ix, iy); puts(borrar_avion);
                gotoxy(ix, iy +1); puts(borrar_avion);
                gotoxy(ix, iy +2); puts(borrar_avion);

                // le da movimiento al avion hacia la izquierda
                ix -= 2;

                // ahora dibujamos el avion en las nuevas coordenadas
                gotoxy(ix, iy); puts(avion_l1);
                gotoxy(ix, iy +1); puts(avion_l2);
                gotoxy(ix, iy +2); puts(avion_l3);
            }
            break;

        case DERECHA:
            // para que no se salga de la pantalla
            if(ix < 70)
            {
                gotoxy(ix, iy); puts(borrar_avion);
                gotoxy(ix, iy +1); puts(borrar_avion);
                gotoxy(ix, iy +2); puts(borrar_avion);

                // le da movimiento al avion hacia la izquierda
                ix += 2;

                // ahora dibujamos el avion en las nuevas coordenadas
                gotoxy(ix, iy); puts(avion_l1);
                gotoxy(ix, iy +1); puts(avion_l2);
                gotoxy(ix, iy +2); puts(avion_l3);
            }
            break;

        case 'd':
            disparo = true;
            break;
        } // fin del SWITCH
    } // fin del IF

    // rutina para golpes de asteroides
    // coordenadas que abarca el avion en X
    if((x > ix && x < ix +6 && y == iy-1) || (xx > ix && xx < ix +6 && yy == iy-1) || (x1 > ix && x1 < ix +6 && y1 == iy-1) ||(x2 > ix && x2 < ix +6 && y2 == iy-1))
    {
    corazones --;
    barra_salud(corazones);
    printf("\a"); // hace el ruidito cuando le pega

    }
    // imprime el avion
    gotoxy(ix, iy); puts(avion_l1);
    gotoxy(ix, iy +1); puts(avion_l2);
    gotoxy(ix, iy +2); puts(avion_l3);

    if(corazones == 0)
    {
        num_vidas --;
        vidas(num_vidas);
        avion_explota();
        corazones = 3;
        barra_salud(corazones);
    }

    // rutina para cambio de nivel
    if(condicion == false)
    {
        repeticion++;
        condicion = true;
    }
    // cuando el asteroide haya subido 15 veces, sube el nivel
    if(repeticion == 15)
    {
        nivel ++;
        gotoxy(35, 1); cout << "NIVEL: " << nivel;

        //borra el avion de donde estaba y lo imprime mas arriba
        gotoxy(ix, iy); puts(borrar_avion);
        gotoxy(ix, iy+1); puts(borrar_avion);
        gotoxy(ix, iy+2); puts(borrar_avion);

        iy -= 2;

        gotoxy(ix, iy); puts(avion_l1);
        gotoxy(ix, iy+1); puts(avion_l2);
        gotoxy(ix, iy+2); puts(avion_l3);

        // para que se repita el bucle del cambio de nivel
        repeticion = 0;
    }

    // incremento de los asteroides
    y++;
    yy++;
    y1++;
    y2++;

}



