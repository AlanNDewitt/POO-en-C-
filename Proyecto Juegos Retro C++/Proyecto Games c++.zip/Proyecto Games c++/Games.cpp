#include <iostream>
#include "libgame_alan.h"
#include "Snake.h"
#include "Pong.h"
#include "Space Invaders.h"
#include "Racing Car.h"




void Portada_Games()
{
	system("cls");
	
	OcultaCursor();
	
	Beep(300 ,6000);


	
	
	for(int x = 0 ; x < 120; x++)	// LLENAR DE PUNTITOS LA PANTALLA
	{
		gotoxy(x,0);
		cout<<".";
		
		for(int y = 0 ; y < 30 ; y++)
		{
			Color(VERDE2);
			gotoxy(x,y);
			cout<<".";
		}
	}
	

	Color(MORADO);
	
	Color(ROJO);
	
	//marco_Total();
	
	Color(AZUL);
	
	//marco_Secundario();
	
	
	
	Color(ROJO);
	gotoxy(9,10); 
	cout<<":'######::::::'###::::'##::::'##:'########::'######::::::'######::::::::::::::::::";
	gotoxy(9,11);                         
	cout<<"'##... ##::::'## ##::: ###::'###: ##.....::'##... ##::::'##... ##:::'##:::::'##:::";
	gotoxy(9,12);          
  	cout<<" ##:::..::::'##:. ##:: ####'####: ##::::::: ##:::..::::: ##:::..:::: ##::::: ##:::"; 
   	gotoxy(9,13);
  	cout<<" ##::'####:'##:::. ##: ## ### ##: ######:::. ######::::: ##:::::::'######:'######:";
  	gotoxy(9,14);
  	cout<<" ##::: ##:: #########: ##. #: ##: ##...:::::..... ##:::: ##:::::::.. ##.::.. ##.::";
  	gotoxy(9,15);
  	cout<<" ##::: ##:: ##.... ##: ##:.:: ##: ##:::::::'##::: ##:::: ##::: ##::: ##::::: ##:::";
  	gotoxy(9,16);
  	cout<<". ######::: ##:::: ##: ##:::: ##: ########:. ######:::::. ######::::..::::::..::::";
  	gotoxy(9,17);
  	cout<<":......::::..:::::..::..:::::..::........:::......:::::::......:::::::::::::::::::";
  	
  	
  	
  	//gotoxy(15,20);
    //cout<<"By : Edgar Alan ";
  	
	Beep(2000 ,300);
	Beep(1900 ,300);
	Beep(1800 ,300);
	Beep(1700 ,300);
	Beep(1600 ,300);
	Beep(1200 ,4000);
	Beep(1500 ,300);
	
	
	Color(MORADO);
	gotoxy(25,20);
  	cout<<"*************************";
  	gotoxy(25,21);
  	cout<<"*PRESS ENTER TO CONTINUE*";
  	gotoxy(25,22);
  	cout<<"*************************";
  	
  	pausa();
	
}


void Menu_Games()
{
	system("cls");
	
	short opcion;
	
	bool salir;
	
    Beep(1800,300);
	
	do
	{
		
		
		Color(MORADO);
		for(int x = 0 ; x < 120; x++)	// LLENAR DE PUNTITOS LA PANTALLA
		{
			gotoxy(x,0);
			cout<<".";
		
			for(int y = 0 ; y < 30 ; y++)
			{
				gotoxy(x,y);
				cout<<".";
			}
		}
	
		Color(ROJO);
		marco_Total();

		
		Color(AMARILLO);
		gotoxy(20,5);
		cout<<".......##.##.....##.########..######....#######...######.";
		gotoxy(20,6);
		cout<<".......##.##.....##.##.......##....##..##.....##.##....##";
		gotoxy(20,7);
		cout<<".......##.##.....##.##.......##........##.....##.##......";
		gotoxy(20,8);
		cout<<".......##.##.....##.######...##...####.##.....##..######.";
		gotoxy(20,9);
		cout<<".##....##.##.....##.##.......##....##..##.....##.......##";
		gotoxy(20,10);
		cout<<".##....##.##.....##.##.......##....##..##.....##.##....##";
		gotoxy(20,11);
		cout<<"..######...#######..########..######....#######...######.";
	
	
	
		gotoxy(30,13);
		Color(VERDE2);
		cout<<"1.-PONG ";
		gotoxy(30,14);
		Color(ROJO);
		cout<<"*********";
	
		gotoxy(30,17);
		Color(VERDE2);
		cout<<"2.-SNAKE";
		gotoxy(30,18);
		Color(ROJO);
		cout<<"**********";
	
		gotoxy(30,21);
		Color(VERDE2);
		cout<<"3.-SPACE INVADERS";
		gotoxy(30,22);
		Color(ROJO);
		cout<<"******************";
	
		gotoxy(30,25);
		Color(VERDE2);
		cout<<"4.-RACING CAR";
		gotoxy(30,26);
		Color(ROJO);
		cout<<"***************";	
	
		gotoxy(95,26);
		Color(VERDE2);
		cout<<"5.-SALIR  ";
		gotoxy(95,27);
		Color(ROJO);
		cout<<"*********";
	
	
		Color(MORADO);
		gotoxy(100,5);
		cout<<",___,";
		gotoxy(100,6);
		cout<<"[O.o]";
		gotoxy(100,7);
		cout<<"/)__)";
		gotoxy(100,8);
		cout<<" -''-";
	
	
	
	
		Color(AZUL);
		gotoxy(80,18);
		cout<<"--------";
		gotoxy(80,19);
		cout<<"-      -";
		gotoxy(80,20);
		cout<<"--------";
		gotoxy(80,21);
		cout<<"opcion";
	
		gotoxy(83,19);
		cin>>opcion;
	
	
		while(opcion > 5 || opcion < 1 )
		{
			Color(ROJO);
			gotoxy(70,17);
			cout<<" ___";
			gotoxy(70,18);
			cout<<"(._.)";
			gotoxy(70,19);
			cout<<"<|---<";
			gotoxy(70,20);
			cout<<"_||_";
		
			Color(ROJO);
			gotoxy(80,18);
			cout<<"--------";
			gotoxy(80,19);
			cout<<"-      -";
			gotoxy(80,20);
			cout<<"--------";
			gotoxy(80,21);
			Color(ROJO);
			cout<<"opcion";
	
			gotoxy(82,19);
			cin>>opcion;
		}
	
	system("cls");	
		
		switch (opcion)
		{
			case 1 :
				
			  
				
							break;
			case 2 :
					
					SNAKE();
				
							break;
			case 3 :
				
				Space_invaders();
				
							break;
			case 4 :
				
			
							break;
							
			case 5 :
				
				//salir = true;
			
							break;
		}
		
	pausa(1000);	
	Beep(1800,300);
		
	
	} while(opcion != 5);
	
    Beep(300,8000);

}





int main(int argc, char** argv) 
{
	
	Portada_Games();
	
	Menu_Games();
	
	
	return 0;
}





